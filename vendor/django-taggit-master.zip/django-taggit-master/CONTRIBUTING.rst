Please see `Contributing to taggit <https://django-taggit.readthedocs.io/en/latest/contributing.html>`_.
