VERSION = (0, 22, 1)

default_app_config = 'taggit.apps.TaggitAppConfig'
